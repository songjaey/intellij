package com.example.jpatest.test;

import lombok.Data;

@Data
public class TestMember {
    private String name;
    private int age;
    private String tel;
    private String email;
}
