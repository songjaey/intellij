package com.example.jpatest.constant;

public enum Role {
    USER,ADMIN
}
